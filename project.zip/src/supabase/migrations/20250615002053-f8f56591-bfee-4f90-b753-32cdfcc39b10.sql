
-- Удаляем созданную таблицу tire_orders, так как работаем только с Google Sheets
DROP TABLE IF EXISTS public.tire_orders;
